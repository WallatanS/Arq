package br.com.academiadoflutter.flutter_retrofit_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
